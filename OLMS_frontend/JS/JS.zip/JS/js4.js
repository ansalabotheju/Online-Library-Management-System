google.charts.load('current', {'packages':['corechart']});
  google.charts.setOnLoadCallback(drawChart);
  
  // Draw the chart and set the chart values
  function drawChart() {
    var data = google.visualization.arrayToDataTable([
    ['Category', 'Count'],
    ['IT', 3],
    ['Science', 2],
    ['Story', 6],
    ['Fiction', 1],
   
  ]);
  
    // Optional; add a title and set the width and height of the chart
    var options = {'title':'Category', 'width':550, 'height':400};
  
    // Display the chart inside the <div> element with id="piechart"
    var chart = new google.visualization.PieChart(document.getElementById('piechart3'));
    chart.draw(data, options);
  }
